BeHealthy

Gruppo di lavoro:
	Luigi Martinelli
	William Vernillo

Progetto per il corso ISPW A.A. 2021/2022 - Università degli Studi di Roma "Tor Vergata"

Source code: https://github.com/xDefcon/behealthy-app
Sonarcloud: https://sonarcloud.io/summary/overall?id=xDefcon_behealthy-app

Please open "Software Requirement Specification.pdf" for further details.
